﻿$(document).ready(function(){
$(".preloader").fadeOut();
$(".perloader").delay(350).fadeOut();
})
